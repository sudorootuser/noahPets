<?php

/*---------- 
CREACIÓN DE CONSTANTES PARA LA NAVEGACIÓN EN LA PÁGINA WEB
 -----------*/
// const SERVERURL = "https://testadlive.com/noah_client/";

// const SERVERURL = "http://localhost/noahpets/";
const SERVERURL = "http://localhost/programs/noahClient/";

const COMPANY = "Noah Pets";

const MONEDA = "$";

date_default_timezone_set('America/Bogota');
